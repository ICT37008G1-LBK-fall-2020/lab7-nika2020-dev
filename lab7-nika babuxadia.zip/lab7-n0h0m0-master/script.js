

$(document).ready(function (){
    $('body').css('background-color', 'blue');
    $('body').css('opacity', '50%');
})